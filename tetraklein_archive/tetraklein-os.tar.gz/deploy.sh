#!/bin/bash
set -e

echo "🛰️  TetraKlein-OS Field Terminal Deployment"
echo "=========================================="
echo "COLD WAR FIELD DEPLOYMENT SCENARIO"
echo

# Check if podman is installed
if ! command -v podman &> /dev/null; then
    echo "❌ ERROR: Podman not found. Please install podman first."
    exit 1
fi

# Create archive directory if it doesn't exist
mkdir -p tetraklein_archive

# Build tar.gz archive
echo "⚡ Building TetraKlein-OS archive..."
tar -czf tetraklein_archive/tetraklein-os.tar.gz \
    Containerfile \
    deploy.sh \
    tiny_server.js \
    public \
    vault \
    README.md \
    .dockerignore

# Build container
echo "⚡ Building TetraKlein-OS Field Terminal container..."
podman build -t tetraklein-os .

# Run container
echo "⚡ Launching TetraKlein-OS Field Terminal..."
podman run -d \
    --name tetraklein-os \
    --rm \
    -p 127.0.0.1:8080:8080 \
    -v "$(pwd)/vault:/app/vault:Z" \
    tetraklein-os

echo
echo "✅ TetraKlein-OS Field Terminal deployed."
echo "Access via: http://127.0.0.1:8080"
echo "Admin access: http://127.0.0.1:8080/admin"
echo
echo "CLASSIFIED: DESTROY AFTER MISSION COMPLETE"
echo "Container will self-destroy when stopped." 