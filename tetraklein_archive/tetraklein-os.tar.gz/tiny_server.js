const express = require('express');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const { execSync } = require('child_process');
const fs = require('fs');

// Initialize Express app
const app = express();
const PORT = 8080;

// Apply security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:'],
    }
  }
}));

// Enable compression
app.use(compression());

// Only allow localhost connections
app.use((req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress;
  if (ip !== '127.0.0.1' && ip !== '::1' && ip !== '::ffff:127.0.0.1') {
    return res.status(403).send('ACCESS DENIED: LOCALHOST CONNECTIONS ONLY');
  }
  next();
});

// Prevent directory listing
app.use((req, res, next) => {
  if (req.path.includes('..')) {
    return res.status(403).send('SECURITY VIOLATION DETECTED');
  }
  next();
});

// Parse JSON bodies
app.use(express.json());

// Serve static files with restricted options
app.use(express.static(path.join(__dirname, 'public'), {
  dotfiles: 'deny',
  index: false
}));

// Home route - CRT Terminal UI
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Admin route - Top Secret Dashboard
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Command endpoint
app.post('/command', (req, res) => {
  const { command } = req.body;
  if (!command) {
    return res.status(400).json({ error: 'Command is required' });
  }
  
  // Process command and return response
  try {
    const response = processCommand(command);
    res.json({ response });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Command processor
function processCommand(command) {
  const commands = {
    'login': () => {
      return {
        type: 'login',
        message: 'SECURE LOGIN SEQUENCE INITIATED\nEnter password:'
      };
    },
    'help': () => {
      return {
        type: 'help',
        message: `Available commands:
- help: Show this help message
- login: Start login sequence
- status: Show system status
- clear: Clear terminal
- meshstatus: Show mesh network status
- admin: Access admin dashboard
- time: Show current time
- vault: List vault contents`
      };
    },
    'status': () => {
      return {
        type: 'status',
        message: 'SYSTEM STATUS: OPERATIONAL\nSECURITY: MAXIMUM\nCONNECTION: SECURE'
      };
    },
    'clear': () => {
      return {
        type: 'clear',
        message: ''
      };
    },
    'meshstatus': () => {
      let status = 'MESH NETWORK STATUS: ';
      try {
        // Attempt to check Yggdrasil status
        execSync('pgrep yggdrasil');
        status += 'ACTIVE\nENCRYPTION: ENABLED';
      } catch (error) {
        status += 'INACTIVE';
      }
      return {
        type: 'meshstatus',
        message: status
      };
    },
    'admin': () => {
      return {
        type: 'admin',
        message: 'Redirecting to admin dashboard...',
        redirect: '/admin'
      };
    },
    'time': () => {
      return {
        type: 'time',
        message: `Current time: ${new Date().toLocaleTimeString()}`
      };
    },
    'vault': () => {
      try {
        const files = fs.readdirSync('/app/vault');
        return {
          type: 'vault',
          message: files.length ? `Vault contents:\n${files.join('\n')}` : 'Vault is empty'
        };
      } catch (error) {
        return {
          type: 'error',
          message: `Vault access error: ${error.message}`
        };
      }
    }
  };

  const [cmd] = command.toLowerCase().split(' ');
  if (cmd in commands) {
    return commands[cmd]();
  }
  return {
    type: 'error',
    message: 'Command not recognized. Type "help" for available commands.'
  };
}

// Start server on localhost only
app.listen(PORT, '127.0.0.1', () => {
  console.log(`TetraKlein-OS Field Terminal running on http://127.0.0.1:${PORT}`);
  console.log('COLD WAR FIELD DEPLOYMENT ACTIVE');
}); 