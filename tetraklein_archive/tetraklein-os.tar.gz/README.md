# TetraKlein-OS Field Terminal

**CLASSIFICATION: TOP SECRET**

Cold War Field Deployment Scenario terminal operating purely in Podman with zero disk trace.

## Requirements

- Podman installed
- 64MB RAM minimum
- Secure environment

## Quick Deployment

Run the deployment script to build and launch the TetraKlein-OS Field Terminal:

```
./deploy.sh
```

## Access Points

- Terminal Interface: http://127.0.0.1:8080
- Admin Dashboard: http://127.0.0.1:8080/admin

## Security Features

- RAM-only operation — container destroys itself after stop
- Public-facing services bound to localhost only
- Hardened Node.js server with security headers
- No directory listing
- Yggdrasil mesh networking with auto-configuration
- Vault folder for classified file storage

## Architecture

- Alpine Linux base (minimal footprint)
- Node.js + Express
- No external frameworks (no React, Vite, or Webpack)
- Cold War style green-on-black CRT terminal UI
- Secure Top Secret Mesh Dashboard

## Important Notes

1. The container is configured to self-destruct when stopped
2. All data stored in the vault folder is mounted from the host
3. No data is persisted within the container after shutdown
4. Yggdrasil daemon runs as a background service

## Command Reference

Available in the terminal interface by typing `help`.

## Mission Guidelines

1. Maintain secure communications
2. Destroy all evidence after mission completion
3. Keep all traffic localhost-bound
4. Use vault folder for classified storage

---

*DESTROY THIS DOCUMENT AFTER READING* 